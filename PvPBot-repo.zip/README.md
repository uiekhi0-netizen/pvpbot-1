# PvPBot

Minecraft (Paper 1.21.x) plugin that spawns fake-player PvP bots.
Requires the **Citizens** plugin on the server.

## Commands
- `/pvpbot spawn <name|random> <count|random>`
- `/pvpbot set diamond` - full diamond armor, diamond sword, 2 totems, 10 golden apples
- `/pvpbot remove`

Permission: `pvpbot.use`

## Build
GitHub Actions builds the jar on every push: open the **Actions** tab -> latest run -> **Artifacts** -> `PvPBot`.

Local: `mvn clean package` -> `target/PvPBot-1.0.0.jar`
