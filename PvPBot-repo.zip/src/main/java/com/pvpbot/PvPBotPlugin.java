package com.pvpbot;

import net.citizensnpcs.api.CitizensAPI;
import net.citizensnpcs.api.npc.MemoryNPCDataStore;
import net.citizensnpcs.api.npc.NPC;
import net.citizensnpcs.api.npc.NPCRegistry;
import net.citizensnpcs.api.trait.trait.Equipment;
import net.citizensnpcs.api.trait.trait.Equipment.EquipmentSlot;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.EntityEffect;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.*;

public class PvPBotPlugin extends JavaPlugin implements Listener, TabExecutor {

    /** state of each bot */
    private static class Bot {
        final NPC npc;
        int totems = 2;
        int gapples = 10;
        long lastAttack = 0;
        long lastEat = 0;
        Bot(NPC npc) { this.npc = npc; }
    }

    private static final int MAX_PER_COMMAND = 50;
    private static final double ATTACK_RANGE = 3.2;
    private static final double SEARCH_RANGE = 48;

    private final Map<UUID, Bot> bots = new HashMap<>();
    private final Random rnd = new Random();
    private NPCRegistry registry;
    private String kit = "diamond";

    private static final String[] PREFIX = {"Dark", "Pro", "Ninja", "Shadow", "Toxic", "Epic", "Fire",
            "Ice", "Sky", "Mad", "Lazy", "Cool", "Blue", "Red", "Wolf", "Tiger", "Ender", "Ghost"};
    private static final String[] SUFFIX = {"Gamer", "Killer", "Slayer", "King", "Boy", "Girl", "PvP",
            "Master", "YT", "Hunter", "Craft", "Man", "Lord", "Z", "X", "TH"};

    @Override
    public void onEnable() {
        registry = CitizensAPI.createAnonymousNPCRegistry(new MemoryNPCDataStore());
        Bukkit.getPluginManager().registerEvents(this, this);
        getCommand("pvpbot").setExecutor(this);
        Bukkit.getScheduler().runTaskTimer(this, this::tickAI, 20L, 4L);
    }

    @Override
    public void onDisable() {
        removeAll();
        if (registry != null) registry.deregisterAll();
    }

    // ---------------------------------------------------------------- commands
    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 0) { usage(s); return true; }

        switch (a[0].toLowerCase()) {
            case "spawn" -> {
                if (!(s instanceof Player p)) { s.sendMessage("ใช้ได้เฉพาะในเกม"); return true; }
                if (a.length < 3) { usage(s); return true; }

                int count;
                if (a[2].equalsIgnoreCase("random")) count = 1 + rnd.nextInt(5);
                else {
                    try { count = Integer.parseInt(a[2]); }
                    catch (NumberFormatException e) { s.sendMessage(ChatColor.RED + "จำนวนต้องเป็นตัวเลข หรือ random"); return true; }
                }
                count = Math.max(1, Math.min(MAX_PER_COMMAND, count));

                boolean randomName = a[1].equalsIgnoreCase("random");
                for (int i = 0; i < count; i++) {
                    String name = randomName ? randomName() : (count == 1 ? a[1] : a[1] + "_" + (i + 1));
                    if (name.length() > 16) name = name.substring(0, 16);
                    spawnBot(name, p.getLocation().add(rnd.nextDouble() * 4 - 2, 0, rnd.nextDouble() * 4 - 2));
                }
                s.sendMessage(ChatColor.GREEN + "เสกบอทแล้ว " + count + " ตัว");
            }
            case "set" -> {
                if (a.length < 2 || !a[1].equalsIgnoreCase("diamond")) { usage(s); return true; }
                kit = "diamond";
                for (Bot b : bots.values()) giveDiamondKit(b);
                s.sendMessage(ChatColor.AQUA + "ตั้งชุดบอทเป็น diamond แล้ว (เกราะเพชรครบ, ดาบเพชร, totem 2, golden apple 10)");
            }
            case "remove" -> {
                int n = bots.size();
                removeAll();
                s.sendMessage(ChatColor.YELLOW + "ลบบอท " + n + " ตัว");
            }
            default -> usage(s);
        }
        return true;
    }

    private void usage(CommandSender s) {
        s.sendMessage(ChatColor.YELLOW + "/pvpbot spawn <ชื่อ|random> <จำนวน|random>");
        s.sendMessage(ChatColor.YELLOW + "/pvpbot set diamond");
        s.sendMessage(ChatColor.YELLOW + "/pvpbot remove");
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 1) return filter(List.of("spawn", "set", "remove"), a[0]);
        if (a[0].equalsIgnoreCase("spawn")) {
            if (a.length == 2) return filter(List.of("random"), a[1]);
            if (a.length == 3) return filter(List.of("random", "1", "5", "10"), a[2]);
        }
        if (a[0].equalsIgnoreCase("set") && a.length == 2) return filter(List.of("diamond"), a[1]);
        return List.of();
    }

    private List<String> filter(List<String> src, String prefix) {
        List<String> out = new ArrayList<>();
        for (String x : src) if (x.toLowerCase().startsWith(prefix.toLowerCase())) out.add(x);
        return out;
    }

    // ---------------------------------------------------------------- spawning
    private String randomName() {
        for (int t = 0; t < 20; t++) {
            String n = PREFIX[rnd.nextInt(PREFIX.length)] + SUFFIX[rnd.nextInt(SUFFIX.length)]
                    + (rnd.nextInt(3) == 0 ? "" : String.valueOf(rnd.nextInt(100)));
            if (n.length() <= 16 && Bukkit.getPlayerExact(n) == null && !nameUsed(n)) return n;
        }
        return "Bot" + rnd.nextInt(99999);
    }

    private boolean nameUsed(String n) {
        for (Bot b : bots.values()) if (b.npc.getName().equalsIgnoreCase(n)) return true;
        return false;
    }

    private void spawnBot(String name, Location loc) {
        NPC npc = registry.createNPC(EntityType.PLAYER, name);
        npc.setProtected(false);
        npc.spawn(loc);
        Bot bot = new Bot(npc);
        bots.put(npc.getUniqueId(), bot);
        giveDiamondKit(bot);

        // announce like a real join
        Bukkit.broadcastMessage(ChatColor.YELLOW + name + " joined the game");
    }

    private void giveDiamondKit(Bot bot) {
        bot.totems = 2;
        bot.gapples = 10;

        Equipment eq = bot.npc.getOrAddTrait(Equipment.class);
        eq.set(EquipmentSlot.HELMET, new ItemStack(Material.DIAMOND_HELMET));
        eq.set(EquipmentSlot.CHESTPLATE, new ItemStack(Material.DIAMOND_CHESTPLATE));
        eq.set(EquipmentSlot.LEGGINGS, new ItemStack(Material.DIAMOND_LEGGINGS));
        eq.set(EquipmentSlot.BOOTS, new ItemStack(Material.DIAMOND_BOOTS));
        eq.set(EquipmentSlot.HAND, new ItemStack(Material.DIAMOND_SWORD));
        eq.set(EquipmentSlot.OFF_HAND, new ItemStack(Material.TOTEM_OF_UNDYING));

        // keep the spare items in the inventory too (1 totem + 10 golden apples)
        if (bot.npc.getEntity() instanceof Player p) {
            p.getInventory().setItem(1, new ItemStack(Material.TOTEM_OF_UNDYING, 1));
            p.getInventory().setItem(2, new ItemStack(Material.GOLDEN_APPLE, 10));
        }
    }

    private void removeAll() {
        for (Bot b : new ArrayList<>(bots.values())) b.npc.destroy();
        bots.clear();
    }

    // ---------------------------------------------------------------- AI
    private void tickAI() {
        long now = System.currentTimeMillis();
        for (Bot bot : bots.values()) {
            NPC npc = bot.npc;
            if (!npc.isSpawned() || !(npc.getEntity() instanceof Player me)) continue;

            // eat golden apple when low
            if (me.getHealth() < 10 && bot.gapples > 0 && now - bot.lastEat > 1600) {
                bot.lastEat = now;
                bot.gapples--;
                me.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 100, 1));
                me.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 2400, 0));
                me.getWorld().playSound(me.getLocation(), org.bukkit.Sound.ENTITY_GENERIC_EAT, 1f, 1f);
                me.swingMainHand();
            }

            Player target = nearestTarget(me);
            if (target == null) { npc.getNavigator().cancelNavigation(); continue; }

            double dist = me.getLocation().distance(target.getLocation());
            if (dist > ATTACK_RANGE - 0.5) {
                npc.getNavigator().getDefaultParameters().speedModifier(1.3f);
                npc.getNavigator().setTarget(target.getLocation());
            }
            if (dist <= ATTACK_RANGE && now - bot.lastAttack >= 600) {
                bot.lastAttack = now;
                me.swingMainHand();
                target.damage(7.0, me);   // diamond sword damage
            }
        }
    }

    private Player nearestTarget(Player me) {
        Player best = null;
        double bestD = SEARCH_RANGE * SEARCH_RANGE;
        for (Player p : me.getWorld().getPlayers()) {
            if (registry.isNPC(p) || CitizensAPI.getNPCRegistry().isNPC(p)) continue;
            if (p.isDead()) continue;
            if (p.getGameMode() != GameMode.SURVIVAL && p.getGameMode() != GameMode.ADVENTURE) continue;
            double d = p.getLocation().distanceSquared(me.getLocation());
            if (d < bestD) { bestD = d; best = p; }
        }
        return best;
    }

    // ---------------------------------------------------------------- totem + death
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        Bot bot = botOf(e.getEntity());
        if (bot == null) return;
        Player me = (Player) e.getEntity();

        double hp = me.getHealth() + me.getAbsorptionAmount();
        if (e.getFinalDamage() >= hp && bot.totems > 0) {
            e.setCancelled(true);
            bot.totems--;
            me.setHealth(1.0);
            me.setAbsorptionAmount(0);
            me.clearActivePotionEffects();
            me.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 900, 1));
            me.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 100, 1));
            me.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 800, 0));
            me.playEffect(EntityEffect.TOTEM_RESURRECT);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(EntityDeathEvent e) {
        Bot bot = botOf(e.getEntity());
        if (bot == null) return;

        bots.remove(bot.npc.getUniqueId());
        e.getDrops().clear();
        e.setDroppedExp(0);
        String name = bot.npc.getName();

        // show "left the game" like a real player disconnecting
        Bukkit.broadcastMessage(ChatColor.YELLOW + name + " left the game");
        Bukkit.getScheduler().runTaskLater(this, () -> bot.npc.destroy(), 1L);
    }

    private Bot botOf(Entity en) {
        if (en == null) return null;
        NPC npc = registry.getNPC(en);
        return npc == null ? null : bots.get(npc.getUniqueId());
    }
}
